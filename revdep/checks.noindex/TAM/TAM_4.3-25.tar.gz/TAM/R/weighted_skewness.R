## File Name: weighted_skewness.R
## File Version: 9.11


# weighted skewness
weighted_skewness <- function( x, w=rep(1,length(x)), select=NULL )
{
    res <- tam_weighted_stats_select(x=x, w=w, select=select)
    x <- res$x
    w <- res$w
    m <- weighted_mean( x=x, w=w)
    s <- weighted_sd( x=x, w=w)
    y <- ((x-m)/s)^3
    res <- weighted_mean(x=y, w=w)
    return(res)
}
